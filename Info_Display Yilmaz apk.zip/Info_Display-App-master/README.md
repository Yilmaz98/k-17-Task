# Info_Display-App
This app collects basic information about a person and displays the user input.